===== WeDesignTech Portfolio =====

WeDesignTech Potfolio plugin adds complete portfolio modules to built portfolio section in your site.


== Changelog ==

= 1.0.3 =

  * Fixed : Security issues

= 1.0.2 =
  
  * Fixed: Notice error 

= 1.0.1 =

    * Fixed: Elementor Deprecated error
    
= 1.0.0 =

    * First release!