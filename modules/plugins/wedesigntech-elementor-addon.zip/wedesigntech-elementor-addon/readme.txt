===== WeDesignTech Elementor Addon =====

WeDesignTech Elementor Addon plugin adds additional modules for Elementor plugin.


== Changelog ==

= 1.0.9=
  
    * Compatible with latest Elementor Version.
    * Fixed: Tab's mobile layout issue.

= 1.0.8=

  
  * Fixed: Notice error 

= 1.0.7 =

    * Fixed : Warnings and deprecated errors
    * Compatible with latest Elementor Version

= 1.0.6 =

    * Fixed : Warnings and deprecated errors
    * Compatible with latest Elementor Version

= 1.0.5 =

    * Fixed : Warnings and deprecated errors
    * Compatible with latest Elementor Version
 

= 1.0.4 =

  * Compatible : Latest Elementor Version

= 1.0.3 =

    * Compatible: Latest Elementor Version 3.16.6

= 1.0.2 =

    * Compatible: Latest Elementor Version 3.16.2

= 1.0.1 =

    * Fixed: Elementor Deprecated error

= 1.0.0 =

    * First release!