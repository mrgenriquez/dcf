<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'NammOrganicPlusCustomizerSite404' ) ) {
    class NammOrganicPlusCustomizerSite404 {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_action( 'customize_register', array( $this, 'register' ), 15);
        }

        function register( $wp_customize ) {

            /**
             * 404 Page
             */
            $wp_customize->add_section(
                new NammOrganic_Customize_Section(
                    $wp_customize,
                    'site-404-page-section',
                    array(
                        'title'    => esc_html__('404 Page', 'namm-organic-plus'),
                        'priority' => namm_organic_customizer_panel_priority( '404' )
                    )
                )
            );

            if ( ! defined( 'NAMM_ORGANIC_PRO_VERSION' ) ) {
                $wp_customize->add_control(
                    new NammOrganic_Customize_Control_Separator(
                        $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[namm_organic-plus-site-404-separator]',
                        array(
                            'type'        => 'wdt-separator',
                            'section'     => 'site-404-page-section',
                            'settings'    => array(),
                            'caption'     => NAMM_ORGANIC_PLUS_REQ_CAPTION,
                            'description' => NAMM_ORGANIC_PLUS_REQ_DESC,
                        )
                    )
                );
            }

        }

    }
}

NammOrganicPlusCustomizerSite404::instance();