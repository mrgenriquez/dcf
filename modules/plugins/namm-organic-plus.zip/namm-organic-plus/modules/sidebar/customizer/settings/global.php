<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'NammOrganicPlusGlobalSibarSettings' ) ) {
    class NammOrganicPlusGlobalSibarSettings {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_filter( 'namm_organic_plus_customizer_default', array( $this, 'default' ) );
            add_action( 'customize_register', array( $this, 'register' ), 15);
        }

        function default( $option ) {
            $option['global_sidebar_layout'] = 'content-full-width';
            $option['global_sidebar']        = '';
            $option['hide_standard_sidebar'] = '';
            return $option;
        }

        function register( $wp_customize ) {

            /**
             * Global Sidebar Panel
             */
            $wp_customize->add_section(
                new NammOrganic_Customize_Section(
                    $wp_customize,
                    'site-global-sidebar-section',
                    array(
                        'title'    => esc_html__('Global Sidebar', 'namm-organic-plus'),
                        'panel'    => 'site-widget-main-panel',
                        'priority' => 5
                    )
                )
            );

                /**
                 * Option: Global Sidebar Layout
                 */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[global_sidebar_layout]', array(
                            'type' => 'option',
                        )
                    );

                    $wp_customize->add_control( new NammOrganic_Customize_Control_Radio_Image(
                        $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[global_sidebar_layout]', array(
                            'type'    => 'wdt-radio-image',
                            'label'   => esc_html__( 'Global Sidebar Layout', 'namm-organic-plus'),
                            'section' => 'site-global-sidebar-section',
                            'choices' => apply_filters( 'namm_organic_global_sidebar_layouts', array(
                                'content-full-width' => array(
                                    'label' => esc_html__( 'Without Sidebar', 'namm-organic-plus' ),
                                    'path'  =>  NAMM_ORGANIC_PLUS_DIR_URL . 'modules/sidebar/customizer/images/without-sidebar.png'
                                ),
                                'with-left-sidebar'  => array(
                                    'label' => esc_html__( 'With Left Sidebar', 'namm-organic-plus' ),
                                    'path'  =>  NAMM_ORGANIC_PLUS_DIR_URL . 'modules/sidebar/customizer/images/left-sidebar.png'
                                ),
                                'with-right-sidebar' => array(
                                    'label' => esc_html__( 'With Right Sidebar', 'namm-organic-plus' ),
                                    'path'  =>  NAMM_ORGANIC_PLUS_DIR_URL . 'modules/sidebar/customizer/images/right-sidebar.png'
                                ),
                            ) )
                        )
                    ) );

                /**
                 * Option : Hide Standard Sidebar
                 */
                $wp_customize->add_setting(
                    NAMM_ORGANIC_CUSTOMISER_VAL . '[hide_standard_sidebar]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new NammOrganic_Customize_Control_Switch(
                        $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[hide_standard_sidebar]', array(
                            'type'    => 'wdt-switch',
                            'section' => 'site-global-sidebar-section',
                            'label'   => esc_html__( 'Hide Standard Sidebar', 'namm-organic-plus' ),
                            'choices' => array(
                                'on'  => esc_attr__( 'Yes', 'namm-organic-plus' ),
                                'off' => esc_attr__( 'No', 'namm-organic-plus' )
                            )
                        )
                    )
                );

                if ( ! defined( 'NAMM_ORGANIC_PRO_VERSION' ) ) {
                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Separator(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[namm_organic-plus-site-global-sidebar-separator]',
                            array(
                                'type'        => 'wdt-separator',
                                'section'     => 'site-global-sidebar-section',
                                'settings'    => array(),
                                'caption'     => NAMM_ORGANIC_PLUS_REQ_CAPTION,
                                'description' => NAMM_ORGANIC_PLUS_REQ_DESC,
                            )
                        )
                    );
                }

        }
    }
}

NammOrganicPlusGlobalSibarSettings::instance();