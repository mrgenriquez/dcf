<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'NammOrganicPlusBCYoast' ) ) {
    class NammOrganicPlusBCYoast {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_action( 'plugins_loaded', array( $this, 'register_init' ) );
        }

        function register_init() {
            if ( defined( 'WPSEO_VERSION' ) ) {
                $this->load_backend();
                $this->load_frontend();
            }
        }

        function load_backend() {
            add_filter( 'namm_organic_breadcrumb_source', array( $this, 'register_option' ) );
        }

        function load_frontend() {
            add_filter( 'namm_organic_breadcrumb_get_template_part', array( $this, 'register_template' ), 10 );
        }

        function register_option( $options ) {
            $options['yoast-seo'] = esc_html__('Yoast SEO','namm-organic-plus');
            return $options;
        }

        function register_template() {

            $bc_source = namm_organic_customizer_settings( 'breadcrumb_source' );

            if( $bc_source === 'yoast-seo' ) {
                namm_organic_template_part( 'breadcrumb', 'templates/yoast-seo/title-content', '', $template_args );

            }
        }
    }
}

NammOrganicPlusBCYoast::instance();