<div class="pre-loader loader2">
    <div class="loader-inner">
    <span class="loader-text"><?php echo esc_html__('Loading..','namm-organic-plus'); ?></span>
    </div>
</div>