<div class="pre-loader loader3">
    <div class="loader-inner">
        <div class="loader-custom"></div>
    </div>
</div>