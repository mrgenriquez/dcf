<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if (! class_exists ( 'NammOrganicPlusFooterPostType' ) ) {

	class NammOrganicPlusFooterPostType {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

		function __construct() {

			add_action ( 'init', array( $this, 'namm_organic_register_cpt' ) );
			add_filter ( 'template_include', array ( $this, 'namm_organic_template_include' ) );
		}

		function namm_organic_register_cpt() {

			$labels = array (
				'name'				 => __( 'Footers', 'namm-organic-plus' ),
				'singular_name'		 => __( 'Footer', 'namm-organic-plus' ),
				'menu_name'			 => __( 'Footers', 'namm-organic-plus' ),
				'add_new'			 => __( 'Add Footer', 'namm-organic-plus' ),
				'add_new_item'		 => __( 'Add New Footer', 'namm-organic-plus' ),
				'edit'				 => __( 'Edit Footer', 'namm-organic-plus' ),
				'edit_item'			 => __( 'Edit Footer', 'namm-organic-plus' ),
				'new_item'			 => __( 'New Footer', 'namm-organic-plus' ),
				'view'				 => __( 'View Footer', 'namm-organic-plus' ),
				'view_item' 		 => __( 'View Footer', 'namm-organic-plus' ),
				'search_items' 		 => __( 'Search Footers', 'namm-organic-plus' ),
				'not_found' 		 => __( 'No Footers found', 'namm-organic-plus' ),
				'not_found_in_trash' => __( 'No Footers found in Trash', 'namm-organic-plus' ),
			);

			$args = array (
				'labels' 				=> $labels,
				'public' 				=> true,
				'exclude_from_search'	=> true,
				'show_in_nav_menus' 	=> false,
				'show_in_rest' 			=> true,
				'menu_position'			=> 26,
				'menu_icon' 			=> 'dashicons-editor-insertmore',
				'hierarchical' 			=> false,
				'supports' 				=> array ( 'title', 'editor', 'revisions' ),
			);

			register_post_type ( 'wdt_footers', $args );
		}

		function namm_organic_template_include($template) {
			if ( is_singular( 'wdt_footers' ) ) {
				if ( ! file_exists ( get_stylesheet_directory () . '/single-wdt_footers.php' ) ) {
					$template = NAMM_ORGANIC_PLUS_DIR_PATH . 'post-types/templates/single-wdt_footers.php';
				}
			}

			return $template;
		}
	}
}

NammOrganicPlusFooterPostType::instance();