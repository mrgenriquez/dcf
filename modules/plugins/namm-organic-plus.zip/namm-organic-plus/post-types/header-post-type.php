<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if (! class_exists ( 'NammOrganicPlusHeaderPostType' ) ) {

	class NammOrganicPlusHeaderPostType {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

		function __construct() {

			add_action ( 'init', array( $this, 'namm_organic_register_cpt' ), 5 );
			add_filter ( 'template_include', array ( $this, 'namm_organic_template_include' ) );
		}

		function namm_organic_register_cpt() {

			$labels = array (
				'name'				 => __( 'Headers', 'namm-organic-plus' ),
				'singular_name'		 => __( 'Header', 'namm-organic-plus' ),
				'menu_name'			 => __( 'Headers', 'namm-organic-plus' ),
				'add_new'			 => __( 'Add Header', 'namm-organic-plus' ),
				'add_new_item'		 => __( 'Add New Header', 'namm-organic-plus' ),
				'edit'				 => __( 'Edit Header', 'namm-organic-plus' ),
				'edit_item'			 => __( 'Edit Header', 'namm-organic-plus' ),
				'new_item'			 => __( 'New Header', 'namm-organic-plus' ),
				'view'				 => __( 'View Header', 'namm-organic-plus' ),
				'view_item' 		 => __( 'View Header', 'namm-organic-plus' ),
				'search_items' 		 => __( 'Search Headers', 'namm-organic-plus' ),
				'not_found' 		 => __( 'No Headers found', 'namm-organic-plus' ),
				'not_found_in_trash' => __( 'No Headers found in Trash', 'namm-organic-plus' ),
			);

			$args = array (
				'labels' 				=> $labels,
				'public' 				=> true,
				'exclude_from_search'	=> true,
				'show_in_nav_menus' 	=> false,
				'show_in_rest' 			=> true,
				'menu_position'			=> 25,
				'menu_icon' 			=> 'dashicons-heading',
				'hierarchical' 			=> false,
				'supports' 				=> array ( 'title', 'editor', 'revisions' ),
			);

			register_post_type ( 'wdt_headers', $args );
		}

		function namm_organic_template_include($template) {
			if ( is_singular( 'wdt_headers' ) ) {
				if ( ! file_exists ( get_stylesheet_directory () . '/single-wdt_headers.php' ) ) {
					$template = NAMM_ORGANIC_PLUS_DIR_PATH . 'post-types/templates/single-wdt_headers.php';
				}
			}

			return $template;
		}
	}
}

NammOrganicPlusHeaderPostType::instance();