======= NammOrganic Plus =====

NammOrganic Plus plugin adds additonal features for NammOrganic theme.


== Changelog ==

= 1.0.6=

  * Fixed: Fixed Breadcrumb template issue.
  * Fixed: Sitcky Header Search Overlay issue.

= 1.0.5=

  
  * Fixed: Notice error 

= 1.0.4=

  
  * Minor error fixed 

= 1.0.3=

  * Translation issue fixed 
  * Minor error fixed 


= 1.0.2=

  * Minor error fixed 

= 1.0.1=

  * Importer error fixed 

= 1.0.0 =

    * First release!