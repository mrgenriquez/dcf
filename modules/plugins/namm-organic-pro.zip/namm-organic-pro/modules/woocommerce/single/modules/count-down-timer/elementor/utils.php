<?php

/*
* Update Summary - Options Filter
*/

if( ! function_exists( 'namm_organic_shop_woo_single_summary_options_cnamm_organic_render' ) ) {
	function namm_organic_shop_woo_single_summary_options_cnamm_organic_render( $options ) {

		$options['countdown'] = esc_html__('Summary Count Down', 'namm-organic-pro');
		return $options;

	}
	add_filter( 'namm_organic_shop_woo_single_summary_options', 'namm_organic_shop_woo_single_summary_options_cnamm_organic_render', 10, 1 );

}

/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'namm_organic_shop_woo_single_summary_styles_cnamm_organic_render' ) ) {
	function namm_organic_shop_woo_single_summary_styles_cnamm_organic_render( $styles ) {

		array_push( $styles, 'wdt-shop-coundown-timer' );
		return $styles;

	}
	add_filter( 'namm_organic_shop_woo_single_summary_styles', 'namm_organic_shop_woo_single_summary_styles_cnamm_organic_render', 10, 1 );

}

/*
* Update Summary - Scripts Filter
*/

if( ! function_exists( 'namm_organic_shop_woo_single_summary_scripts_cnamm_organic_render' ) ) {
	function namm_organic_shop_woo_single_summary_scripts_cnamm_organic_render( $scripts ) {

		array_push( $scripts, 'jquery-downcount' );
		array_push( $scripts, 'wdt-shop-coundown-timer' );
		return $scripts;

	}
	add_filter( 'namm_organic_shop_woo_single_summary_scripts', 'namm_organic_shop_woo_single_summary_scripts_cnamm_organic_render', 10, 1 );

}