<?php

/**
 * WooCommerce - Single - Module - Social Share & Follow - Customizer Settings
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'NammOrganic_Shop_Customizer_Single_Social_Share_And_Follow' ) ) {

    class NammOrganic_Shop_Customizer_Single_Social_Share_And_Follow {

        private static $_instance = null;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            add_filter( 'namm_organic_woo_single_page_settings', array( $this, 'single_page_settings' ), 10, 1 );
            add_action( 'customize_register', array( $this, 'register' ), 15);

        }

        function single_page_settings( $settings ) {

            $product_show_sharer_facebook                = namm_organic_customizer_settings('wdt-single-product-show-sharer-facebook' );
            $settings['product_show_sharer_facebook']    = $product_show_sharer_facebook;

            $product_show_sharer_delicious               = namm_organic_customizer_settings('wdt-single-product-show-sharer-delicious' );
            $settings['product_show_sharer_delicious']   = $product_show_sharer_delicious;

            $product_show_sharer_digg                    = namm_organic_customizer_settings('wdt-single-product-show-sharer-digg' );
            $settings['product_show_sharer_digg']        = $product_show_sharer_digg;

            $product_show_sharer_twitter                 = namm_organic_customizer_settings('wdt-single-product-show-sharer-twitter' );
            $settings['product_show_sharer_twitter']     = $product_show_sharer_twitter;

            $product_show_sharer_linkedin                = namm_organic_customizer_settings('wdt-single-product-show-sharer-linkedin' );
            $settings['product_show_sharer_linkedin']    = $product_show_sharer_linkedin;

            $product_show_sharer_pinterest               = namm_organic_customizer_settings('wdt-single-product-show-sharer-pinterest' );
            $settings['product_show_sharer_pinterest']   = $product_show_sharer_pinterest;

            return $settings;

        }

        function register( $wp_customize ) {

            /**
            * Share
            */

                /**
                * Option : Sharer Description
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-description]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-description]', array(
                                'type'        => 'wdt-description',
                                'label'       => esc_html__( 'Note: ', 'namm-organic-pro'),
                                'section'     => 'woocommerce-single-page-sociable-share-section',
                                'description' => esc_html__( 'This option is applicable only for WooCommerce "Custom Template".', 'namm-organic-pro')
                            )
                        )
                    );

                /**
                * Option : Show Facebook Sharer
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-facebook]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-facebook]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Facebook Sharer', 'namm-organic-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Delicious Sharer
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-delicious]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-delicious]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Delicious Sharer', 'namm-organic-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Digg Sharer
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-digg]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-digg]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Digg Sharer', 'namm-organic-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Twitter Sharer
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-twitter]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-twitter]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Twitter Sharer', 'namm-organic-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show LinkedIn Sharer
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-linkedin]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-linkedin]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show LinkedIn Sharer', 'namm-organic-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Pinterest Sharer
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-pinterest]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-pinterest]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Pinterest Sharer', 'namm-organic-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-pro' )
                                )
                            )
                        )
                    );

            /**
            * Follow
            */

                /**
                * Option : Follow Description
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-follow-description]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-follow-description]', array(
                                'type'    => 'wdt-description',
                                'label'   => esc_html__( 'Note :', 'namm-organic-pro'),
                                'section' => 'woocommerce-single-page-sociable-follow-section',
                                'description'   => esc_html__( 'This option is applicable only for WooCommerce "Custom Template".', 'namm-organic-pro'),
                            )
                        )
                    );

                    $social_follow = array (
                        'delicious'   => esc_html__('Delicious', 'namm-organic-pro'),
                        'deviantart'  => esc_html__('Deviantart', 'namm-organic-pro'),
                        'digg'        => esc_html__('Digg', 'namm-organic-pro'),
                        'dribbble'    => esc_html__('Dribbble', 'namm-organic-pro'),
                        'envelope'    => esc_html__('Envelope', 'namm-organic-pro'),
                        'facebook'    => esc_html__('Facebook', 'namm-organic-pro'),
                        'flickr'      => esc_html__('Flickr', 'namm-organic-pro'),
                        'google-plus' => esc_html__('Google Plus', 'namm-organic-pro'),
                        'instagram'   => esc_html__('Instagram', 'namm-organic-pro'),
                        'lastfm'      => esc_html__('Lastfm', 'namm-organic-pro'),
                        'linkedin'    => esc_html__('Linkedin', 'namm-organic-pro'),
                        'myspace'     => esc_html__('Myspace', 'namm-organic-pro'),
                        'pinterest'   => esc_html__('Pinterest', 'namm-organic-pro'),
                        'reddit'      => esc_html__('Reddit', 'namm-organic-pro'),
                        'rss'         => esc_html__('RSS', 'namm-organic-pro'),
                        'skype'       => esc_html__('Skype', 'namm-organic-pro'),
                        'stumbleupon' => esc_html__('Stumbleupon', 'namm-organic-pro'),
                        'tumblr'      => esc_html__('Tumblr', 'namm-organic-pro'),
                        'twitter'     => esc_html__('Twitter', 'namm-organic-pro'),
                        'viadeo'      => esc_html__('Viadeo', 'namm-organic-pro'),
                        'vimeo'       => esc_html__('Vimeo', 'namm-organic-pro'),
                        'yahoo'       => esc_html__('Yahoo', 'namm-organic-pro'),
                        'youtube'     => esc_html__('Youtube', 'namm-organic-pro')
                    );

                    foreach($social_follow as $socialfollow_key => $socialfollow) {

                        $wp_customize->add_setting(
                            NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-follow-'.$socialfollow_key.']', array(
                                'type' => 'option'
                            )
                        );

                        $wp_customize->add_control(
                            new NammOrganic_Customize_Control_Switch(
                                $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-show-follow-'.$socialfollow_key.']', array(
                                    'type'    => 'wdt-switch',
                                    'label'   => sprintf(esc_html__('Show %1$s Follow', 'namm-organic-pro'), $socialfollow),
                                    'section' => 'woocommerce-single-page-sociable-follow-section',
                                    'choices' => array(
                                        'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
                                        'off' => esc_attr__( 'No', 'namm-organic-pro' )
                                    )
                                )
                            )
                        );

                        $wp_customize->add_setting(
                            NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-follow-'.$socialfollow_key.'-link]', array(
                                'type' => 'option'
                            )
                        );

                        $wp_customize->add_control(
                            new NammOrganic_Customize_Control(
                                $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-single-product-follow-'.$socialfollow_key.'-link]', array(
                                    'type'       => 'text',
                                    'section'    => 'woocommerce-single-page-sociable-follow-section',
                                    'input_attrs' => array(
                                        'placeholder' => sprintf(esc_html__('%1$s Link', 'namm-organic-pro'), $socialfollow)
                                    ),
                                    'dependency' => array ( 'wdt-single-product-show-follow-'.$socialfollow_key, '==', '1' )
                                )
                            )
                        );

                    }

        }

    }

}


if( !function_exists('namm_organic_shop_customizer_single_social_share_and_follow') ) {
	function namm_organic_shop_customizer_single_social_share_and_follow() {
		return NammOrganic_Shop_Customizer_Single_Social_Share_And_Follow::instance();
	}
}

namm_organic_shop_customizer_single_social_share_and_follow();