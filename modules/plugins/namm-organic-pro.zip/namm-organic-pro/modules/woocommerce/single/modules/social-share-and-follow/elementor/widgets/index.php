<?php

namespace NammOrganicElementor\Widgets;
use NammOrganicElementor\Widgets\NammOrganic_Shop_Widget_Product_Summary;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;


class NammOrganic_Shop_Widget_Product_Summary_Extend extends NammOrganic_Shop_Widget_Product_Summary {

	function dynamic_register_controls() {

		$this->start_controls_section( 'product_summary_extend_section', array(
			'label' => esc_html__( 'Social Options', 'namm-organic-pro' ),
		) );

			$this->add_control( 'share_follow_type', array(
				'label'   => esc_html__( 'Share / Follow Type', 'namm-organic-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'share',
				'options' => array(
					''       => esc_html__('None', 'namm-organic-pro'),
					'share'  => esc_html__('Share', 'namm-organic-pro'),
					'follow' => esc_html__('Follow', 'namm-organic-pro'),
				),
				'description' => esc_html__( 'Choose between Share / Follow you would like to use.', 'namm-organic-pro' ),
			) );

			$this->add_control( 'social_icon_style', array(
				'label'   => esc_html__( 'Social Icon Style', 'namm-organic-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					'simple'        => esc_html__( 'Simple', 'namm-organic-pro' ),
					'bgfill'        => esc_html__( 'BG Fill', 'namm-organic-pro' ),
					'brdrfill'      => esc_html__( 'Border Fill', 'namm-organic-pro' ),
					'skin-bgfill'   => esc_html__( 'Skin BG Fill', 'namm-organic-pro' ),
					'skin-brdrfill' => esc_html__( 'Skin Border Fill', 'namm-organic-pro' ),
				),
				'description' => esc_html__( 'This option is applicable for all buttons used in product summary.', 'namm-organic-pro' ),
				'condition'   => array( 'share_follow_type' => array ('share', 'follow') )
			) );

			$this->add_control( 'social_icon_radius', array(
				'label'   => esc_html__( 'Social Icon Radius', 'namm-organic-pro' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					'square'  => esc_html__( 'Square', 'namm-organic-pro' ),
					'rounded' => esc_html__( 'Rounded', 'namm-organic-pro' ),
					'circle'  => esc_html__( 'Circle', 'namm-organic-pro' ),
				),
				'condition'   => array(
					'social_icon_style' => array ('bgfill', 'brdrfill', 'skin-bgfill', 'skin-brdrfill'),
					'share_follow_type' => array ('share', 'follow')
				),
			) );

			$this->add_control( 'social_icon_inline_alignment', array(
				'label'        => esc_html__( 'Social Icon Inline Alignment', 'namm-organic-pro' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'yes', 'namm-organic-pro' ),
				'label_off'    => esc_html__( 'no', 'namm-organic-pro' ),
				'default'      => '',
				'return_value' => 'true',
				'description'  => esc_html__( 'This option is applicable for all buttons used in product summary.', 'namm-organic-pro' ),
				'condition'   => array( 'share_follow_type' => array ('share', 'follow') )
			) );

		$this->end_controls_section();

	}

}