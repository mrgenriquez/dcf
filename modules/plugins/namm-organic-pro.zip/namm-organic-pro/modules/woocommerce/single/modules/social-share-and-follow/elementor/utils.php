<?php

/*
* Update Summary Options Filter
*/

if( ! function_exists( 'namm_organic_shop_woo_single_summary_options_ssf_render' ) ) {
	function namm_organic_shop_woo_single_summary_options_ssf_render( $options ) {

		$options['share_follow'] = esc_html__('Summary Share / Follow', 'namm-organic-pro');
		return $options;

	}
	add_filter( 'namm_organic_shop_woo_single_summary_options', 'namm_organic_shop_woo_single_summary_options_ssf_render', 10, 1 );

}


/*
* Update Summary - Styles Filter
*/

if( ! function_exists( 'namm_organic_shop_woo_single_summary_styles_ssf_render' ) ) {
	function namm_organic_shop_woo_single_summary_styles_ssf_render( $styles ) {

		array_push( $styles, 'wdt-shop-social-share-and-follow' );
		return $styles;

	}
	add_filter( 'namm_organic_shop_woo_single_summary_styles', 'namm_organic_shop_woo_single_summary_styles_ssf_render', 10, 1 );

}
