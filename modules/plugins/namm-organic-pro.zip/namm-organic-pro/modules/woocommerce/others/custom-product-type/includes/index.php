<?php


// Product Custom Type

if( ! function_exists( 'namm_organic_shop_woo_loop_product_custom_type' ) ) {

	function namm_organic_shop_woo_loop_product_custom_type($product_id) {

        $output = '';

        // Product weight
        $product_show_weight = wc_get_loop_prop( 'product-show-weight' );
        $product_show_weight = ($product_show_weight == '' || (isset($product_show_weight) && $product_show_weight == 'true')) ? true : false;

        if( $product_show_weight ) {
            global $product;
            $weight_unit = get_option('woocommerce_weight_unit');
            $attributes = $product->get_attributes();

            if ( $product->has_weight() ) {
                $output .= '<div class="product-weight">';
                    $output .= '<span class="product-weight-label">'. $product->get_weight() . $weight_unit .'</span>';
                $output .= '</div>';
            }
        }

        $product_show_custom_type = wc_get_loop_prop( 'product-show-custom-type' );
        $product_show_custom_type = ($product_show_custom_type == '' || (isset($product_show_custom_type) && $product_show_custom_type == 'true')) ? true : false;

        if( $product_show_custom_type ) {

            $settings = get_post_meta( $product_id, '_custom_product_type', true );

            if(isset($settings['custom-product-type']) && $settings['custom-product-type'] != '') {

                $woo_others_settings = namm_organic_woo_others()->woo_default_settings();
                $custom_product_types = explode(',', $woo_others_settings['custom_product_types']);

                if(isset($custom_product_types[$settings['custom-product-type']]) && !empty($custom_product_types[$settings['custom-product-type']])) {
                    $output .= '<div class="product-custom-type">';
                        $output .= '<span class="product-custom-type-label">'.$custom_product_types[$settings['custom-product-type']].'</span>';
                    $output .= '</div>';
                }
            }

        }

		echo namm_organic_html_output( $output );

    }

    add_action( 'namm_organic_woo_before_product_thumb_image', 'namm_organic_shop_woo_loop_product_custom_type', 10, 1 );

}