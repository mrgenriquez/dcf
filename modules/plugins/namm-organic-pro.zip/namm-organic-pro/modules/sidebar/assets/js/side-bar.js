(function ($) {
    "use strict";
	$(document).ready(function() {
        if( $("#secondary").length ) {
            $('.secondary-sidebar')
                .theiaStickySidebar({
                    additionalMarginTop: 40,
                    containerSelector: $('#primary')
                });
        }
    });
})(jQuery);