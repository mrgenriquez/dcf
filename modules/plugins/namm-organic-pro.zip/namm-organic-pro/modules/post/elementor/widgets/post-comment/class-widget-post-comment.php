<?php
use NammOrganicElementor\Widgets\NammOrganicElementorWidgetBase;
use Elementor\Controls_Manager;
use Elementor\Utils;

class Elementor_Post_Comments extends NammOrganicElementorWidgetBase {

    public function get_name() {
        return 'wdt-post-comments';
    }

    public function get_title() {
        return esc_html__('Post - Comments', 'namm-organic-pro');
    }

    protected function register_controls() {

        $this->start_controls_section( 'wdt_section_general', array(
            'label' => esc_html__( 'General', 'namm-organic-pro'),
        ) );

            $this->add_control( 'style', array(
                'type'    => Controls_Manager::SELECT,
				'label'   => esc_html__('Style', 'namm-organic-pro'),
                'default' => '',
                'options' => array(
                    ''  => esc_html__('Default', 'namm-organic-pro'),
                    'meta-elements-space'		 => esc_html__('Space', 'namm-organic-pro'),
                    'meta-elements-boxed'  		 => esc_html__('Boxed', 'namm-organic-pro'),
                    'meta-elements-boxed-curvy'  => esc_html__('Curvy', 'namm-organic-pro'),
                    'meta-elements-boxed-round'  => esc_html__('Round', 'namm-organic-pro'),
					'meta-elements-filled'  	 => esc_html__('Filled', 'namm-organic-pro'),
					'meta-elements-filled-curvy' => esc_html__('Filled Curvy', 'namm-organic-pro'),
					'meta-elements-filled-round' => esc_html__('Filled Round', 'namm-organic-pro'),
                ),
            ) );

            $this->add_control( 'el_class', array(
                'type'        => Controls_Manager::TEXT,
                'label'       => esc_html__('Extra class name', 'namm-organic-pro'),
                'description' => esc_html__('Style particular element differently - add a class name and refer to it in custom CSS', 'namm-organic-pro')
            ) );

        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings_for_display();

        extract($settings);

		$out = '';

        global $post;
        $post_id =  $post->ID;

        $Post_Style = namm_organic_get_single_post_style( $post_id );

		$template_args['post_ID'] = $post_id;
		$template_args['post_Style'] = $Post_Style;
        $template_args = array_merge( $template_args, namm_organic_single_post_params() );

		$out .= '<div class="entry-comments-wrapper '.$style.' '.$el_class.'">';
            $out .= namm_organic_get_template_part( 'post', 'templates/'.$Post_Style.'/parts/comment', '', $template_args );
		$out .= '</div>';

		echo $out;
	}

}