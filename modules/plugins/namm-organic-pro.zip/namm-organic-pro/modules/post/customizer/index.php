<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'NammOrganicProCustomizerBlogPost' ) ) {
    class NammOrganicProCustomizerBlogPost {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_filter( 'namm_organic_pro_customizer_default', array( $this, 'default' ) );
			add_action( 'customize_register', array( $this, 'register' ), 20 );
        }

        function default( $option ) {

            $post_defaults = array();
            if( function_exists('namm_organic_single_post_params_default') ) {
                $post_defaults = namm_organic_single_post_params_default();
            }

            $option['enable_title'] 		  = $post_defaults['enable_title'];
            $option['enable_image_lightbox']  = $post_defaults['enable_image_lightbox'];
			$option['enable_disqus_comments'] = $post_defaults['enable_disqus_comments'];
			$option['post_disqus_shortname']  = $post_defaults['post_disqus_shortname'];
			$option['post_dynamic_elements']  = $post_defaults['post_dynamic_elements'];
            $option['post_commentlist_style'] = $post_defaults['post_commentlist_style'];

            $post_misc_defaults = array();
            if( function_exists('namm_organic_single_post_misc_default') ) {
                $post_misc_defaults = namm_organic_single_post_misc_default();
            }

            $option['enable_related_article'] = $post_misc_defaults['enable_related_article'];
			$option['rposts_title']    		  = $post_misc_defaults['rposts_title'];
			$option['rposts_column']   		  = $post_misc_defaults['rposts_column'];
			$option['rposts_count']    		  = $post_misc_defaults['rposts_count'];
			$option['rposts_excerpt']  		  = $post_misc_defaults['rposts_excerpt'];
			$option['rposts_excerpt_length']  = $post_misc_defaults['rposts_excerpt_length'];
			$option['rposts_carousel']  	  = $post_misc_defaults['rposts_carousel'];
			$option['rposts_carousel_nav']    = $post_misc_defaults['rposts_carousel_nav'];

            return $option;
        }

        function register( $wp_customize ) {

			/**
			 * Option : Post Title
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_title]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Switch(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_title]', array(
						'type'    => 'wdt-switch',
						'label'   => esc_html__( 'Enable Title', 'namm-organic-pro'),
						'description' => esc_html__('YES! to enable the title of single post.', 'namm-organic-pro'),
						'section' => 'site-blog-post-section',
						'choices' => array(
							'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
							'off' => esc_attr__( 'No', 'namm-organic-pro' )
						)
					)
				)
			);

			/**
			 * Option : Post Elements
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[post_dynamic_elements]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Sortable(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[post_dynamic_elements]', array(
						'type' => 'wdt-sortable',
						'label' => esc_html__( 'Post Elements Positioning', 'namm-organic-pro'),
						'section' => 'site-blog-post-section',
						'choices' => apply_filters( 'namm_organic_blog_post_dynamic_elements', array(
							'author'		=> esc_html__('Author', 'namm-organic-pro'),
							'author_bio' 	=> esc_html__('Author Bio', 'namm-organic-pro'),
							'category'    	=> esc_html__('Categories', 'namm-organic-pro'),
							'comment' 		=> esc_html__('Comments', 'namm-organic-pro'),
							'comment_box' 	=> esc_html__('Comment Box', 'namm-organic-pro'),
							'content'    	=> esc_html__('Content', 'namm-organic-pro'),
							'date'     		=> esc_html__('Date', 'namm-organic-pro'),
							'image'			=> esc_html__('Feature Image', 'namm-organic-pro'),
							'navigation'    => esc_html__('Navigation', 'namm-organic-pro'),
							'tag'  			=> esc_html__('Tags', 'namm-organic-pro'),
							'title'      	=> esc_html__('Title', 'namm-organic-pro'),
							'likes_views'   => esc_html__('Likes & Views', 'namm-organic-pro'),
							'related_posts' => esc_html__('Related Posts', 'namm-organic-pro'),
							'social'  		=> esc_html__('Social Share', 'namm-organic-pro'),
						)
					),
				)
			));

			/**
			 * Option : Image Lightbox
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_image_lightbox]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Switch(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_image_lightbox]', array(
						'type'    => 'wdt-switch',
						'label'   => esc_html__( 'Feature Image Lightbox', 'namm-organic-pro'),
						'description' => esc_html__('YES! to enable lightbox for feature image. Will not work in "Overlay" style.', 'namm-organic-pro'),
						'section' => 'site-blog-post-section',
						'choices' => array(
							'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
							'off' => esc_attr__( 'No', 'namm-organic-pro' )
						)
					)
				)
			);

			/**
			 * Option : Related Article
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_related_article]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Switch(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_related_article]', array(
						'type'    => 'wdt-switch',
						'label'   => esc_html__( 'Enable Related Article', 'namm-organic-pro'),
						'description' => esc_html__('YES! to enable related article at right hand side of post.', 'namm-organic-pro'),
						'section' => 'site-blog-post-section',
						'choices' => array(
							'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
							'off' => esc_attr__( 'No', 'namm-organic-pro' )
						)
					)
				)
			);

			/**
			 * Option : Disqus Comments
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_disqus_comments]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Switch(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[enable_disqus_comments]', array(
						'type'    => 'wdt-switch',
						'label'   => esc_html__( 'Enable Disqus Comments', 'namm-organic-pro'),
						'description' => esc_html__('YES! to enable disqus platform comments module.', 'namm-organic-pro'),
						'section' => 'site-blog-post-section',
						'choices' => array(
							'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
							'off' => esc_attr__( 'No', 'namm-organic-pro' )
						)
					)
				)
			);

			/**
			 * Option : Disqus Short Name
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[post_disqus_shortname]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[post_disqus_shortname]', array(
						'type'    	  => 'textarea',
						'section'     => 'site-blog-post-section',
						'label'       => esc_html__( 'Shortname', 'namm-organic-pro' ),
						'input_attrs' => array(
							'placeholder' => 'disqus',
						),
						'dependency' => array( 'enable_disqus_comments', '==', 'true' ),
					)
				)
			);

			/**
			 * Option : Disqus Description
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[post_disqus_description]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Description(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[post_disqus_description]', array(
						'type'    	  => 'wdt-description',
						'section'     => 'site-blog-post-section',
						'description' => esc_html__('Your site\'s unique identifier', 'namm-organic-pro').' '.'<a href="'.esc_url('https://help.disqus.com/customer/portal/articles/466208').'" target="_blank">'.esc_html__('What is this?', 'namm-organic-pro').'</a>',
						'dependency' => array( 'enable_disqus_comments', '==', 'true' ),
					)
				)
			);

			/**
			 * Option : Comment List Style
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[post_commentlist_style]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control( new NammOrganic_Customize_Control(
				$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[post_commentlist_style]', array(
					'type'    => 'select',
					'section' => 'site-blog-post-section',
					'label'   => esc_html__( 'Comments List Style', 'namm-organic-pro' ),
					'choices' => array(
						'rounded' 	=> esc_html__('Rounded', 'namm-organic-pro'),
						'square'   	=> esc_html__('Square', 'namm-organic-pro'),
					),
					'description' => esc_html__('Choose comments list style to display single post.', 'namm-organic-pro'),
					'dependency' => array( 'enable_disqus_comments', '!=', 'true' ),
				)
			));

			/**
			 * Option : Post Related Title
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_title]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_title]', array(
						'type'    	  => 'text',
						'section'     => 'site-blog-post-section',
						'label'       => esc_html__( 'Related Posts Section Title', 'namm-organic-pro' ),
						'description' => esc_html__('Put the related posts section title here', 'namm-organic-pro'),
						'input_attrs' => array(
							'value'	=> esc_html__('Related Posts', 'namm-organic-pro'),
						)
					)
				)
			);

			/**
			 * Option : Related Columns
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_column]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control( new NammOrganic_Customize_Control_Radio_Image(
				$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_column]', array(
					'type' => 'wdt-radio-image',
					'label' => esc_html__( 'Columns', 'namm-organic-pro'),
					'section' => 'site-blog-post-section',
					'choices' => apply_filters( 'namm_organic_blog_post_related_columns', array(
						'one-column' => array(
							'label' => esc_html__( 'One Column', 'namm-organic-pro' ),
							'path' => NAMM_ORGANIC_PRO_DIR_URL . 'modules/post/customizer/images/one-column.png'
						),
						'one-half-column' => array(
							'label' => esc_html__( 'One Half Column', 'namm-organic-pro' ),
							'path' => NAMM_ORGANIC_PRO_DIR_URL . 'modules/post/customizer/images/one-half-column.png'
						),
						'one-third-column' => array(
							'label' => esc_html__( 'One Third Column', 'namm-organic-pro' ),
							'path' => NAMM_ORGANIC_PRO_DIR_URL . 'modules/post/customizer/images/one-third-column.png'
						),
					)),
				)
			));

			/**
			 * Option : Related Count
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_count]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_count]', array(
						'type'    	  => 'text',
						'section'     => 'site-blog-post-section',
						'label'       => esc_html__( 'No.of Posts to Show', 'namm-organic-pro' ),
						'description' => esc_html__('Put the no.of related posts to show', 'namm-organic-pro'),
						'input_attrs' => array(
							'value'	=> 3,
						),
					)
				)
			);

			/**
			 * Option : Enable Excerpt
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_excerpt]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Switch(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_excerpt]', array(
						'type'    => 'wdt-switch',
						'label'   => esc_html__( 'Enable Excerpt Text', 'namm-organic-pro'),
						'section' => 'site-blog-post-section',
						'choices' => array(
							'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
							'off' => esc_attr__( 'No', 'namm-organic-pro' )
						)
					)
				)
			);

			/**
			 * Option : Excerpt Text
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_excerpt_length]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_excerpt_length]', array(
						'type'    	  => 'text',
						'section'     => 'site-blog-post-section',
						'label'       => esc_html__( 'Excerpt Length', 'namm-organic-pro' ),
						'description' => esc_html__('Put Excerpt Length', 'namm-organic-pro'),
						'input_attrs' => array(
							'value'	=> 25,
						),
						'dependency' => array( 'rposts_excerpt', '==', 'true' ),
					)
				)
			);

			/**
			 * Option : Related Carousel
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_carousel]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control(
				new NammOrganic_Customize_Control_Switch(
					$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_carousel]', array(
						'type'    => 'wdt-switch',
						'label'   => esc_html__( 'Enable Carousel', 'namm-organic-pro'),
						'description' => esc_html__('YES! to enable carousel related posts', 'namm-organic-pro'),
						'section' => 'site-blog-post-section',
						'choices' => array(
							'on'  => esc_attr__( 'Yes', 'namm-organic-pro' ),
							'off' => esc_attr__( 'No', 'namm-organic-pro' )
						)
					)
				)
			);

			/**
			 * Option : Related Carousel Nav
			 */
			$wp_customize->add_setting(
				NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_carousel_nav]', array(
					'type' => 'option',
				)
			);

			$wp_customize->add_control( new NammOrganic_Customize_Control(
				$wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[rposts_carousel_nav]', array(
					'type'    => 'select',
					'section' => 'site-blog-post-section',
					'label'   => esc_html__( 'Navigation Style', 'namm-organic-pro' ),
					'choices' => array(
						'' 			 => esc_html__('None', 'namm-organic-pro'),
						'navigation' => esc_html__('Navigations', 'namm-organic-pro'),
						'pager'   	 => esc_html__('Pager', 'namm-organic-pro'),
					),
					'description' => esc_html__('Choose navigation style to display related post carousel.', 'namm-organic-pro'),
					'dependency' => array( 'rposts_carousel', '==', 'true' ),
				)
			));

        }
    }
}

NammOrganicProCustomizerBlogPost::instance();