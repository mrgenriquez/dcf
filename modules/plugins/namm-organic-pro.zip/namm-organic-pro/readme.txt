===== NammOrganic Pro =====

NammOrganic Pro plugin adds advanced features for NammOrganic theme.


== Changelog ==


= 1.0.4=

  * Added admin template option for single product pages and update related settings

= 1.0.3=

  * Deprecated Errors Fixed

= 1.0.2=

  * Deprecated Errors Fixed

= 1.0.1=

  * Deprecated Errors Fixed

= 1.0.0 =

    * First release!