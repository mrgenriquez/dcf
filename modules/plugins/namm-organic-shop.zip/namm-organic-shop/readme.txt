===== NammOrganic Shop =====

NammOrganic Shop plugin adds shop features for NammOrganic theme.


== Changelog ==

= 1.0.2=

  
  * Fixed: Notice error 

= 1.0.1 =

    * Fixed : Warnings and deprecated errors

= 1.0.0 =

    * First release!