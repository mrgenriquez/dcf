<?php

/**
 * Listing Customizer - Category Settings
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'NammOrganic_Shop_Listing_Customizer_Category' ) ) {

    class NammOrganic_Shop_Listing_Customizer_Category {

        private static $_instance = null;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            add_filter( 'namm_organic_woo_category_page_default_settings', array( $this, 'category_page_default_settings' ), 10, 1 );
            add_action( 'customize_register', array( $this, 'register' ), 40);
            add_action( 'namm_organic_hook_content_before', array( $this, 'woo_handle_product_breadcrumb' ), 10);

        }

        function category_page_default_settings( $settings ) {

            $disable_breadcrumb             = namm_organic_customizer_settings('wdt-woo-category-page-disable-breadcrumb' );
            $settings['disable_breadcrumb'] = $disable_breadcrumb;

            $show_sorter_on_header              = namm_organic_customizer_settings('wdt-woo-category-page-show-sorter-on-header' );
            $settings['show_sorter_on_header']  = $show_sorter_on_header;

            $sorter_header_elements             = namm_organic_customizer_settings('wdt-woo-category-page-sorter-header-elements' );
            $settings['sorter_header_elements'] = (is_array($sorter_header_elements) && !empty($sorter_header_elements) ) ? $sorter_header_elements : array ();

            $show_sorter_on_footer              = namm_organic_customizer_settings('wdt-woo-category-page-show-sorter-on-footer' );
            $settings['show_sorter_on_footer']  = $show_sorter_on_footer;

            $sorter_footer_elements             = namm_organic_customizer_settings('wdt-woo-category-page-sorter-footer-elements' );
            $settings['sorter_footer_elements'] = (is_array($sorter_footer_elements) && !empty($sorter_footer_elements) ) ? $sorter_footer_elements : array ();

            return $settings;

        }

        function register( $wp_customize ) {

                /**
                * Option : Disable Breadcrumb
                */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-disable-breadcrumb]', array(
                            'type' => 'option',
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-disable-breadcrumb]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Disable Breadcrumb', 'namm-organic-shop'),
                                'section' => 'woocommerce-category-page-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-shop' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-shop' )
                                )
                            )
                        )
                    );


                /**
                 * Option : Show Sorter On Header
                 */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-show-sorter-on-header]', array(
                            'type' => 'option',
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-show-sorter-on-header]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Sorter On Header', 'namm-organic-shop'),
                                'section' => 'woocommerce-category-page-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-shop' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-shop' )
                                )
                            )
                        )
                    );

                /**
                 * Option : Sorter Header Elements
                 */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-sorter-header-elements]', array(
                            'type' => 'option',
                        )
                    );

                    $wp_customize->add_control( new NammOrganic_Customize_Control_Sortable(
                        $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-sorter-header-elements]', array(
                            'type' => 'wdt-sortable',
                            'label' => esc_html__( 'Sorter Header Elements', 'namm-organic-shop'),
                            'section' => 'woocommerce-category-page-section',
                            'choices' => apply_filters( 'namm_organic_category_header_sorter_elements', array(
                                'filter'               => esc_html__( 'Filter - OrderBy', 'namm-organic-shop' ),
                                'filters_widget_area'  => esc_html__( 'Filters - Widget Area', 'namm-organic-shop' ),
                                'result_count'         => esc_html__( 'Result Count', 'namm-organic-shop' ),
                                'pagination'           => esc_html__( 'Pagination', 'namm-organic-shop' ),
                                'display_mode'         => esc_html__( 'Display Mode', 'namm-organic-shop' ),
                                'display_mode_options' => esc_html__( 'Display Mode Options', 'namm-organic-shop' )
                            )),
                        )
                    ));

                /**
                 * Option : Show Sorter On Footer
                 */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-show-sorter-on-footer]', array(
                            'type' => 'option',
                        )
                    );

                    $wp_customize->add_control(
                        new NammOrganic_Customize_Control_Switch(
                            $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-show-sorter-on-footer]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Sorter On Footer', 'namm-organic-shop'),
                                'section' => 'woocommerce-category-page-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'namm-organic-shop' ),
                                    'off' => esc_attr__( 'No', 'namm-organic-shop' )
                                )
                            )
                        )
                    );

                /**
                 * Option : Sorter Footer Elements
                 */
                    $wp_customize->add_setting(
                        NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-sorter-footer-elements]', array(
                            'type' => 'option',
                        )
                    );

                    $wp_customize->add_control( new NammOrganic_Customize_Control_Sortable(
                        $wp_customize, NAMM_ORGANIC_CUSTOMISER_VAL . '[wdt-woo-category-page-sorter-footer-elements]', array(
                            'type' => 'wdt-sortable',
                            'label' => esc_html__( 'Sorter Footer Elements', 'namm-organic-shop'),
                            'section' => 'woocommerce-category-page-section',
                            'choices' => apply_filters( 'namm_organic_category_footer_sorter_elements', array(
                                'filter'               => esc_html__( 'Filter', 'namm-organic-shop' ),
                                'result_count'         => esc_html__( 'Result Count', 'namm-organic-shop' ),
                                'pagination'           => esc_html__( 'Pagination', 'namm-organic-shop' ),
                                'display_mode'         => esc_html__( 'Display Mode', 'namm-organic-shop' ),
                                'display_mode_options' => esc_html__( 'Display Mode Options', 'namm-organic-shop' )
                            )),
                        )
                    ));

        }

        function woo_handle_product_breadcrumb() {

            if(is_product_category() && namm_organic_customizer_settings('wdt-woo-category-page-disable-breadcrumb' )) {
                remove_action('namm_organic_breadcrumb', 'namm_organic_breadcrumb_template');
            }

        }

    }

}


if( !function_exists('namm_organic_shop_listing_customizer_category') ) {
	function namm_organic_shop_listing_customizer_category() {
		return NammOrganic_Shop_Listing_Customizer_Category::instance();
	}
}

namm_organic_shop_listing_customizer_category();